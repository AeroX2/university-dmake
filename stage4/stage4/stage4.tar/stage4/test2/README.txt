Memo file .@echo.o is more recent than echo.c
echo is more recent than echo.o
No rules should be executed
