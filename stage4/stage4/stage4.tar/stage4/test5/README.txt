echo.c is more recent than echo.o which is more recent than echo
Memo .@echo.o is more recent than memo .@echo.
Expected action: No compilation.
