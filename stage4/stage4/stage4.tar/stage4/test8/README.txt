oldest is echo.h then echo.o, echo, and echo.c is most recent
Expected action: compile echo.o, discover it has changed,
recompile echo
For all: grep will fail
