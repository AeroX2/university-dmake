# include <stdio.h>

void usage() {
    fprintf (stderr, "Usage: echo text [text ...]\n");
}
