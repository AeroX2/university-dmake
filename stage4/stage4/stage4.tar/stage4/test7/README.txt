oldest is echo.h then echo.o, echo, .@echo.o and echo.c is most recent
Expected action: compile echo.o, discover it has changed, remove the memo file,
recompile echo
