echo.c is more recent than echo which is more recent than echo.o
Expected action: Compile echo.c to echo.o
Set up .@echo.o and backdate echo.o
Don't compile echo
