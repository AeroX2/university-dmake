oldest is say.c then say.o, say, .@say.o and say.h is most recent
Expected action: compile say.o, update the memo file.
