echo.c is more recent than echo.o which is more recent than echo.c
Expected action: Compile echo.c to echo.o, set up memo and backdate echo.o
Then compile echo.o to echo, set up memo and backdate echo
