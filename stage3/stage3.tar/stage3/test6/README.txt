This is a simple Dmakefile that builds a simple program.
Test case where say.c is older than say.
There is a grep command with * modifier that checks content of output from say command
