This is a simple Dmakefile that cleans up and then builds a simple program.
Test case where say.c is older than say.
There is an rm command to remove say.o which will fail.
