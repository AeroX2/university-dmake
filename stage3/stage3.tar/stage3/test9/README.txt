This is a Dmakefile with two simple programs.
cat.c is more recent then cat which is more recent than cat.o
echo.o is more recent than echo which is more recent than echo.c
