This is a simple Dmakefile that builds a simple program.
Test case where say.c is older than say.
There is a grep command with * modifier that checks content of output from say command
There is a bug in say.c so the output is actually incorrect and grep discovers that.
