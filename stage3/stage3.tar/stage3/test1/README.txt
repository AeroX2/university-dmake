This is a simple Dmakefile with a single rule to build a simple program.
Test case where echo.c exists but the program echo does not.
