This is a Dmakefile with two simple programs.
cat is newer than cat.h which is newer than cat.o which is newer than cat.c.
echo.c is newer than echo and echo.o is missing.
echo.c has a syntax error that aborts compilation.
Modifiers @, - and = are included for testing.
