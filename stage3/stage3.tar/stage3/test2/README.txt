This is a simple Dmakefile with a single rule to build a simple program.
Test case where say.c is newer than say.
There is an echo command with @ modifier.
